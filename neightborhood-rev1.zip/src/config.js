export const config = {
  port: 4000, //json-server port
  callForReal: false,
  swOnDev: false // turn on the Service Worker in dev mode
};
